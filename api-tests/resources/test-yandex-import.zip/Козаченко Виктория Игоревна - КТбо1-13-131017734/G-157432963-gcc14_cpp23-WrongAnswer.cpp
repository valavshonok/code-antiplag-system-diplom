// ------------------------------------------------------------------
// Институт компьютерных технологий и информационной безопасности ЮФУ
// Кафедра МОП ЭВМ
// Алгоритмы и структуры данных
// Домашняя работа No 1
// G. Static RSQ
// Исполнитель: Козаченко Виктория Игоревна (КТбо1-13)
// 22.02.2026 г.
// ------------------------------------------------------------------

#include <iostream>
#include <vector>
using namespace std;

vector<long long int> getPrefixSum(vector<long long int> &arr){

    vector<long long int> prefixSum = arr;
    for (int i = 1; i < prefixSum.size(); i++){
        prefixSum[i] += prefixSum[i - 1];
    }
    
    return prefixSum;
} 

int getSum(int l, int r, vector<long long int> &prefixSum){
    
    long long int sum = prefixSum[r];
    if (l > 0){
        sum -= prefixSum[l - 1];
    }
    
    return sum;
}

int main(){
    
    int N, Q;
    cin >> N;
    vector<long long int> arr(N);

    for (auto &x : arr){
        cin >> x;
    }

    cin >> Q;
    vector<pair<int, int>> queries(Q);

    for (auto &[l, r] : queries){
        cin >> l >> r;
    }

    vector<long long int> prefixSum = getPrefixSum(arr);

    for (auto &[l, r] : queries){
        int sum = getSum(l, r, prefixSum);
        cout << sum << endl;
    }
    
    return 0;
}