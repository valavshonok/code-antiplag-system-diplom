// ------------------------------------------------------------------
// Институт компьютерных технологий и информационной безопасности ЮФУ
// Кафедра МОП ЭВМ
// Алгоритмы и структуры данных
// Домашняя работа No 1
// H. Макс и префиксные матрицы
// Исполнитель: Козаченко Виктория Игоревна (КТбо1-13)
// 23.02.2026 г.
// ------------------------------------------------------------------

#include <iostream>
#include <vector>
using namespace std;

int getSum(vector<vector<int>> &prefixSum, int y1, int y2, int x1, int x2){

    int sum = prefixSum[y2][x2];

    if (y1){
        sum -= prefixSum[y1 - 1][x2];
    }
    
    if (x1){
        sum -= prefixSum[y2][x1 - 1];
    }

    if (x1 && y1){
        sum += prefixSum[y1 - 1][x1 - 1];
    }

    return sum;
}

int main(){

    int N, M, Q;

    cin >> N >> M;

    vector<vector<int>> prefixSum (N, vector<int>(M));

    for (int i = 0; i < N; i++){
        for (int j = 0; j < M; j++){
            
            cin >> prefixSum[i][j];
        }
    }

    cin >> Q;

    for (int i = 0; i < Q; i++){
        
        int y1, y2, x1, x2;
        cin >> y1 >> y2 >> x1 >> x2;

        int sum = getSum(prefixSum, y1, y2, x1, x2);

        cout << sum << endl;
    }

    return 0;
}