// ------------------------------------------------------------------
// Институт компьютерных технологий и информационной безопасности ЮФУ
// Кафедра МОП ЭВМ
// Алгоритмы и структуры данных
// Домашняя работа No 1
// Задание C. Уравнение с корнем
// Исполнитель: Козаченко Виктория Игоревна (КТбо1-13)
// 22.02.2026 г.
// ------------------------------------------------------------------

#include <iostream>
#include <cmath>
using namespace std;

int main(){
    
    double a, b, c;
    double x;
    int x1;

    cin >> a >> b >> c;

    if (c < 0){
        cout << "NO SOLUTION";
    }

    else{
        if (a == 0){
            if (b < 0 || sqrt(b) != c){
                cout << "NO SOLUTION";
            }
            else{
                cout << "MANY SOLUTIONS";
            }
        }
        else{
            x = (c*c - b)/a;
            x1 = (c*c - b)/a;
            if (x >= -b/a && x == x1){
            cout << x;
            }
            else{
            cout << "NO SOLUTION";
            }
        }
    }

    return 0;
}