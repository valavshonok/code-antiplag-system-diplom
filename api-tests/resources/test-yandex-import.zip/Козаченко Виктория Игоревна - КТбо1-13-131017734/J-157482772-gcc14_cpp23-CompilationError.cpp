/ ------------------------------------------------------------------
// Институт компьютерных технологий и информационной безопасности ЮФУ
// Кафедра МОП ЭВМ
// Алгоритмы и структуры данных
// Домашняя работа No 1
// J. Проверьте правильность ситуации
// Исполнитель: Козаченко Виктория Игоревна (КТбо1-13)
// 23.02.2026 г.
// ------------------------------------------------------------------

#include <iostream>
#include <vector>
using namespace std;

int main(){

    vector<vector<int>> field(3, vector<int>(3));
    int cnt_1 = 0, cnt_2 = 0, flag1 = 0, win_1 = 0, win_2 = 0;

    for(int i = 0; i < 3; i++){
        for(int j = 0; j < 3; j++){

            cin >> field[i][j];

            if (field[i][j] == 1){
                cnt_1 += 1;
            }
            else if (field[i][j] == 2){
                cnt_2 += 1;
            }
        }
    }

    if (!(cnt_1 == cnt_2 || cnt_1 == cnt_2 + 1)){
        flag1 = 1;
    }

    for (int i = 0; i < 3 && !flag1; i++){
        
        if (field[i][0] == 1 && field[i][1] == 1 && field[i][2] == 1){
            win_1 = 1;
        }
        if (field[i][0] == 2 && field[i][1] == 2 && field[i][2] == 2){
            win_2 = 1;
        }
        if (field[0][i] == 1 && field[1][i] == 1 && field[2][i] == 1){
            win_1 = 1;
        }
        if (field[0][i] == 2 && field[1][i] == 2 && field[2][i] == 2){
            win_2 = 1;
        }
    }

    if (field[0][0] == 1 && field[1][1] == 1 && field[2][2] == 1 && !flag1){
        win_1 = 1;
    }
    if (field[0][0] == 2 && field[1][1] == 2 && field[2][2] == 2 && !flag1){
        win_2 = 1;
    }
    if (field[0][2] == 1 && field[1][1] == 1 && field[2][0] == 1 && !flag1){
        win_1 = 1;
    }
    if (field[0][2] == 2 && field[1][1] == 2 && field[2][0] == 2 && !flag1){
        win_2 = 1;
    }

    if (win_1 && win_2){
        flag1 = 1;
    }

    if ((win_1 == 1 && cnt_1 == cnt_2 )||(win_2 == 1 && cnt_1 == cnt_2 + 1)){
        flag1 = 1;
    }

    if (flag1){
        cout << "NO";
    }
    else{
        cout << "YES";
    }

    return 0;
}