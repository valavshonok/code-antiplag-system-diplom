// ------------------------------------------------------------------
// Институт компьютерных технологий и информационной безопасности ЮФУ
// Кафедра МОП ЭВМ
// Алгоритмы и структуры данных
// Домашняя работа No 1
// I. Иван и коробки
// Исполнитель: Козаченко Виктория Игоревна (КТбо1-13)
// 23.02.2026 г.
// ------------------------------------------------------------------

#include <iostream>
#include <vector>
using namespace std;

int main(){

    int N, Q;
    cin >> N >> Q;

    vector<int> diff(N + 2);
    vector<pair<int, int>> queris(Q);

    for (auto &[l, r] : queris){

        cin >> l >> r;
        diff[l] += 1;
        diff[r + 1] += -1;
    }

    vector<int> diffPrefixSum = diff;

    for (int i = 2; i < N + 1; i++){

        diffPrefixSum[i]+= diffPrefixSum[i - 1];
    }

    for (int i = 1; i < N + 1; i++){

        cout << diffPrefixSum[i] << " ";
    }

    return 0;
}