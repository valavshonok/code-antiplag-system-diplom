// ------------------------------------------------------------------
// Институт компьютерных технологий и информационной безопасности ЮФУ
// Кафедра МОП ЭВМ
// Алгоритмы и структуры данных
// Домашняя работа No 1
// Задание B. Кондиционер
// Исполнитель: Козаченко Виктория Игоревна (КТбо1-13)
// 22.02.2026 г.
// ------------------------------------------------------------------

#include <iostream>
#include <string>
using namespace std;

int main(){
    
    int t_room, t_cond;
    string mode;

    cin >> t_room >> t_cond >> mode;

    if (mode == "freeze"){
        if (t_room > t_cond){
            cout << t_cond;
        }
        else{
            cout << t_room;
        }
    }

    if (mode == "heat"){
        if (t_room < t_cond){
            cout << t_cond;
        }
        else{
            cout << t_room;
        }
    }

    if (mode == "auto"){
        cout << t_cond;
    }

    if (mode == "fan"){
        cout << t_room;
    }

    return 0;
}