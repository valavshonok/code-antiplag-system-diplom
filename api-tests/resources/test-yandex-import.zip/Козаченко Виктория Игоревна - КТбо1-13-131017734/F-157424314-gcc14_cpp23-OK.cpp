// ------------------------------------------------------------------
// Институт компьютерных технологий и информационной безопасности ЮФУ
// Кафедра МОП ЭВМ
// Алгоритмы и структуры данных
// Домашняя работа No 1
// F. Метро
// Исполнитель: Козаченко Виктория Игоревна (КТбо1-13)
// 22.02.2026 г.
// ------------------------------------------------------------------

#include <iostream>
#include <vector>
using namespace std;

int main(){

    int a, b, n, m;
    int flag = 1, max_time = 0, min_time = 1000000;

    cin >> a >> b >> n >> m;

    int min_a = n + (n - 1) * a;
    int max_a = n + (n + 1) * a;

    int min_b = m + (m - 1) * b;
    int max_b = m + (m + 1) * b;

    if (max_a < min_b || max_b < min_a){
        flag = 0;
    }
    if (max_a == min_b){
        max_time = min_time = max_a;
    }
    if (max_b == min_a){
        max_time = min_time = max_b;
    }
    if(max_b == max_a && min_a == min_b){
        max_time = max_a;
        min_time = min_b;
    }
    if (max_a > min_b && max_b > min_a){
        max_time = min(max_a, max_b);
        min_time = max(min_a, min_b);
    }
    
    if (!flag){
        cout << -1;
    }
    else{
        cout << min_time << " " << max_time;
    }

    return 0;
}