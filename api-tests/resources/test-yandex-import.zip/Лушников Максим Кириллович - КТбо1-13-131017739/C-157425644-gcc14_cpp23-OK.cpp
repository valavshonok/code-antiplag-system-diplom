// ЮФУ, ИКТИБ, кафедра МОП ЭВМ
// АиП
// Лушников Максим Кириллович
// АиСД (ВШЭ-ЮФУ), 2026, домашнее задание 1
// Задача C. Уравнение с корнем
// 22.02.2026

#include <iostream>

int main() {
    long long a, b, c;

    std::cin >> a >> b >> c;

    if (c < 0) {
        std::cout << "NO SOLUTION" << std::endl;
        return 0;
    }

    if (a == 0) {
        if (b < 0) {
            std::cout << "NO SOLUTION" << std::endl;
        } else {
            if (c * c == b) {
                std::cout << "MANY SOLUTIONS" << std::endl;
            } else {
                std::cout << "NO SOLUTION" << std::endl;
            }
        }
        return 0;
    }

    long long val = c * c - b;

    if (val % a == 0) {
        std::cout << val / a << std::endl;
    } else {
        std::cout << "NO SOLUTION" << std::endl;
    }

    return 0;
}