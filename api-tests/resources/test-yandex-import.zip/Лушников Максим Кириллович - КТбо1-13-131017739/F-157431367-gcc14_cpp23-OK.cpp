// ЮФУ, ИКТИБ, кафедра МОП ЭВМ
// АиП
// Лушников Максим Кириллович
// АиСД (ВШЭ-ЮФУ), 2026, домашнее задание 1
// Задача F. Метро
// 22.02.2026

#include <iostream>
using namespace std;

int main() {
    int a, b, n, m;
    cin >> a >> b >> n >> m;
    
    int rmin = max(n + a * (n - 1), m + b * (m - 1));
    int rmax = min(n + a * (n + 1), m + b * (m + 1));

    if(rmin > rmax)
        cout << -1 << endl;
    else
        cout << rmin << " " << rmax << endl;

    return 0;
}