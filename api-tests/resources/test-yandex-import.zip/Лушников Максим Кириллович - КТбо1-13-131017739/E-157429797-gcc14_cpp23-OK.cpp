// ЮФУ, ИКТИБ, кафедра МОП ЭВМ
// АиП
// Лушников Максим Кириллович
// АиСД (ВШЭ-ЮФУ), 2026, домашнее задание 1
// Задача E. Детали
// 22.02.2026

#include <iostream>
using namespace std;

int main() {
    int n, m, k;
    cin >> n >> k >> m;

    int total_details = 0;

    if (m <= k) {
        int remain = n;

        while (remain >= k) {
            int blanks = remain / k;
            int used = blanks * k;

            int per_blank = k / m;
            int waste = k % m;

            total_details += blanks * per_blank;

            remain = remain - used + blanks * waste;
        }
    }

    cout << total_details;
    return 0;
}