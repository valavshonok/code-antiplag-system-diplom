// ЮФУ, ИКТИБ, кафедра МОП ЭВМ
// АиП
// Лушников Максим Кириллович
// АиСД (ВШЭ-ЮФУ), 2026, домашнее задание 1
// J. Проверьте правильность ситуации
// 22.02.2026

#include <iostream>
#include <vector>

using namespace std;

bool checkLine(const vector<int>& field, int a, int b, int c, int player) {
    return field[a] == player &&
        field[b] == player &&
        field[c] == player;
}

bool hasWinner(const vector<int>& field, int player) {
    const int patterns[8][3] = {
        {0,1,2}, {3,4,5}, {6,7,8},
        {0,3,6}, {1,4,7}, {2,5,8},
        {0,4,8}, {2,4,6}
    };

    for (int i = 0; i < 8; ++i) {
        if (checkLine(field, patterns[i][0], patterns[i][1], patterns[i][2], player))
            return true;
    }
    return false;
}

int main() {
    vector<int> field(9);
    int countX = 0, countO = 0;

    for (int i = 0; i < 9; ++i) {
        cin >> field[i];
        if (field[i] == 1) countX++;
        if (field[i] == 2) countO++;
    }

    bool xWon = hasWinner(field, 1);
    bool oWon = hasWinner(field, 2);

    bool valid = (countO <= countX && countX <= countO + 1) &&
                (!xWon || countX == countO + 1) &&
                (!oWon || countX == countO);

    cout << (valid ? "YES" : "NO") << endl;
    return 0;
}