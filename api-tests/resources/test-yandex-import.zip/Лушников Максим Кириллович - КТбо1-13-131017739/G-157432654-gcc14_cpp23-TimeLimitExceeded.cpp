// ЮФУ, ИКТИБ, кафедра МОП ЭВМ
// АиП
// Лушников Максим Кириллович
// АиСД (ВШЭ-ЮФУ), 2026, домашнее задание 1
// Задача G. Static RSQ
// 22.02.2026

#include <iostream>
#include <vector>

using namespace std;

int main() {
    int n, q, a, b;
    cin >> n;
    vector<int> ar(n);
    for(int i = 0; i < n; i++){
        cin >> ar[i];
    }
    cin >> q;
    vector<int> arr(q, 0);
    int l, r;
    for(int i = 0; i < q; i++){
        cin >> l >> r;
        for(int j = l; j <= r; j++){
            arr[i] += ar[j];
        }
    }
    for(int i = 0; i < q; i++){
        cout << arr[i] << endl;
    }

    return 0;
}