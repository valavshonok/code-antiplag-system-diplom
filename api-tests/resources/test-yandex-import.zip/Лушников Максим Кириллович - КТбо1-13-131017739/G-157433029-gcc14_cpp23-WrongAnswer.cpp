// ЮФУ, ИКТИБ, кафедра МОП ЭВМ
// АиП
// Лушников Максим Кириллович
// АиСД (ВШЭ-ЮФУ), 2026, домашнее задание 1
// Задача G. Static RSQ
// 22.02.2026

#include <iostream>
#include <vector>

using namespace std;

int main() {
    int n, q, a, b;
    cin >> n;
    vector<int> ar(n);
    for(int i = 0; i < n; i++){
        cin >> ar[i];
        if(i != 0){
            ar[i] += ar[i-1];
        }
    }
    cin >> q;
    vector<int> arr(q, 0);
    int l, r;
    for(int i = 0; i < q; i++){
        cin >> l >> r;
        if(l == 0)
            arr[i] = ar[r];
        else
            arr[i] = ar[r] - ar[l-1];
    }
    for(int i = 0; i < q; i++){
        cout << arr[i] << endl;
    }

    return 0;
}