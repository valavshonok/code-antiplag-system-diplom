// ЮФУ, ИКТИБ, кафедра МОП ЭВМ
// АиП
// Лушников Максим Кириллович
// АиСД (ВШЭ-ЮФУ), 2026, домашнее задание 1
// Задача A. A + B
// 21.02.2026

#include <iostream>
#include <string>

using namespace std;

int main()
{
    int t_now, t_want, res;
    string t;
    cin >> t_now >> t_want >> t;
    

    if(t == "freeze"){
        res = t_now < t_want ? t_now : t_want;
    }
    else if(t == "heat"){
        res = t_now > t_want ? t_now : t_want;
    }
    else if(t == "auto"){
        res = t_want;
    }
    else{
        res = t_now;
    }

    cout << res << endl;
    
    return 0;
}