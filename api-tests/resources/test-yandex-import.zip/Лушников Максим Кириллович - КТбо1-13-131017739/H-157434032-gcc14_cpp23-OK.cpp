// ЮФУ, ИКТИБ, кафедра МОП ЭВМ
// АиП
// Лушников Максим Кириллович
// АиСД (ВШЭ-ЮФУ), 2026, домашнее задание 1
// Задача H. Макс и префиксные матрицы
// 22.02.2026

#include <iostream>
#include <vector>

using namespace std;

int main() {

    int rows, cols;
    cin >> rows >> cols;

    vector<vector<int>> pref(rows, vector<int>(cols));

    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            cin >> pref[i][j];
        }
    }

    int queries;
    cin >> queries;

    while (queries--) {
        int y1, y2, x1, x2;
        cin >> y1 >> y2 >> x1 >> x2;

        int result = pref[y2][x2];
        if (y1 > 0)
            result -= pref[y1 - 1][x2];
        if (x1 > 0)
            result -= pref[y2][x1 - 1];
        if (y1 > 0 && x1 > 0)
            result += pref[y1 - 1][x1 - 1];

        cout << result << '\n';
    }

    return 0;
}