// ЮФУ, ИКТИБ, кафедра МОП ЭВМ
// АиП
// Лушников Максим Кириллович
// АиСД (ВШЭ-ЮФУ), 2026, домашнее задание 1
// J. Проверьте правильность ситуации
// 22.02.2026

#include <iostream>

using namespace std;

int main() {
    int a = 0, b = 0, x;
    for(int i = 0; i < 9; i++){
        cin >> x;
        if(x == 1)
            a++;
        else if(x == 2)
            b++;
    }

    if(a == b){
        if(a != 0){
            cout << "YES" << endl;
        }
    }
    else if(b == (a-1)){
        cout << "YES" << endl;
    }
    else{
        cout << "NO" << endl;
    }
    
    return 0;
}