// ЮФУ, ИКТИБ, кафедра МОП ЭВМ
// АиП
// Лушников Максим Кириллович
// АиСД (ВШЭ-ЮФУ), 2026, домашнее задание 1
// Задача I. Иван и коробки
// 22.02.2026

#include <iostream>
#include <vector>

using namespace std;

int main() {

    int n, q;
    cin >> n >> q;

    vector<int> ar(n + 1);

    int l, r;
    for(int i = 0; i < q; i++){
        cin >> l >> r;
        ar[l-1]++;
        ar[r]--;
    }
    r = ar[0];
    cout << r;
    for(int i = 1; i < n; i++){
        r += ar[i];
        cout << " " << r;
    }

    return 0;
}