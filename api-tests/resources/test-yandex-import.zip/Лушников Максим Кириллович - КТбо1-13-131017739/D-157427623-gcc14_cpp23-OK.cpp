// ЮФУ, ИКТИБ, кафедра МОП ЭВМ
// АиП
// Лушников Максим Кириллович
// АиСД (ВШЭ-ЮФУ), 2026, домашнее задание 1
// Задача D. Расстановка ноутбуков  
// 22.02.2026

#include <iostream>
#include <algorithm>

using namespace std;

int main() {
    int a, b, c, d;
    cin >> a >> b >> c >> d;

    int best_w = 0, best_h = 0;
    int best_area = 1e9;

    int rect1[2] = {a, b};
    int rect2[2] = {c, d};

    for (int i = 0; i < 2; ++i) {
        int w1 = rect1[i];
        int h1 = rect1[1 - i];

        for (int j = 0; j < 2; ++j) {
            int w2 = rect2[j];
            int h2 = rect2[1 - j];

            int w = w1 + w2;
            int h = max(h1, h2);
            if (w * h < best_area) {
                best_area = w * h;
                best_w = w;
                best_h = h;
            }

            w = max(w1, w2);
            h = h1 + h2;
            if (w * h < best_area) {
                best_area = w * h;
                best_w = w;
                best_h = h;
            }
        }
    }

    cout << best_w << " " << best_h << endl;
    return 0;
}