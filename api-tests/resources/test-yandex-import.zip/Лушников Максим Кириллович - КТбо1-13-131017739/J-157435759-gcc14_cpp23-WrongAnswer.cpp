// ЮФУ, ИКТИБ, кафедра МОП ЭВМ
// АиП
// Лушников Максим Кириллович
// АиСД (ВШЭ-ЮФУ), 2026, домашнее задание 1
// J. Проверьте правильность ситуации
// 22.02.2026

#include <iostream>

using namespace std;

int main() {
    int a, b, x;
    for(int i = 0; i < 9; i++){
        cin >> x;
        if(x == 1)
            a++;
        else 
            b++;
    }
    if(b == a || b == (a-1))
        cout << "YES" << endl;
    else
        cout << "NO" << endl;
    
    return 0;
}