// МОП ЭВМ
// АиСП
// ДЗ №1
// Чужиков Даниил Андреевич
// 18.02.2026

#include <iostream>

using namespace std;

int main()
{
    int N, K, M;
    cin >> N >> K >> M;

    if (K < M) {
        cout << 0;
        return 0;
    }

    int total = 0;
    int waste = N;

    while (waste >= K) 
    {
        int colK = waste / K;
        int ostK = waste % K;
        
        int colM = K / M;      
        int ostM = K % M;      
        
        total += colK * colM;
        
        waste = ostK + colK * ostM;
    }

    cout << total;
    return 0;
}