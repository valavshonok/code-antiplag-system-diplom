// МОП ЭВМ
// АиСП
// ДЗ №1
// Чужиков Даниил Андреевич
// 23.02.2026

#include <iostream>
#include <vector>

using namespace std;

int main() {
    int n, q;
    cin >> n >> q;

    vector<int> diff(n + 1, 0);

    while (q--) {
        int l, r;
        cin >> l >> r;
        diff[l] += 1;
        diff[r + 1] -= 1;
    }

    vector<int> res(n + 1, 0);
    for (int i = 1; i <= n; ++i) {
        res[i] = res[i - 1] + diff[i];
    }

    for (int i = 1; i <= n; ++i) {
        cout << res[i];
        if (i < n) cout << " ";
    }
    cout << endl;

    return 0;
}