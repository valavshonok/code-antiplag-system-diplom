// МОП ЭВМ
// АиСП
// ДЗ №1
// Чужиков Даниил Андреевич
// 18.02.2026

#include <iostream>
#include <string>

using namespace std;

int main()
{
    int a, b, c;
    cin >> a >> b >> c;

    if (c < 0) {
        cout << "NO SOLUTION";
    } else if (a == 0) {
        if (b == c*c) {
            cout << "MANY SOLUTIONS";
        } else {
            cout << "NO SOLUTION";
        }
    } else {
        if ((c * c - b) % a != 0) {
            cout << "NO SOLUTION";
        } else {
            int x = (c * c - b) / a;
            
            if (a * x + b < 0) {
                cout << "NO SOLUTION";
            } else {
                cout << x << endl;
            }
        }
    }
    
    return 0;
}