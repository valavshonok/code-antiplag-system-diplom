// МОП ЭВМ
// АиСП
// ДЗ №1
// Чужиков Даниил Андреевич
// 18.02.2026

#include <iostream>
#include <string>

using namespace std;

int main()
{
    int troom, tcond, res;
    string mode;

    cin >> troom >> tcond >> mode;

    if (mode == "heat") {
        res = (troom < tcond) ? tcond : troom;
    } else if (mode == "freeze") {
        res = (troom > tcond) ? tcond : troom;
    } else if (mode == "auto") {
        res = tcond;
    } else {
        res = troom;
    }

    cout << res << endl;

    return 0;
}