// МОП ЭВМ
// АиСП
// ДЗ №1
// Чужиков Даниил Андреевич
// 23.02.2026

#include <iostream>
#include <vector>

using namespace std;

int main() {

    int n, m;
    cin >> n >> m;
    vector<vector<int>> P(n + 1, vector<int>(m + 1, 0));

    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= m; ++j) 
                cin >> P[i][j];    

    int q;
    cin >> q;
    while (q--) {
        int y1, y2, x1, x2;
        cin >> y1 >> y2 >> x1 >> x2;

            int ans = P[y2 + 1][x2 + 1] - P[y1][x2 + 1] - P[y2 + 1][x1] + P[y1][x1];

            cout << ans << "\n";
        }
    }

    return 0;
}