// МОП ЭВМ
// АиСП
// ДЗ №1
// Чужиков Даниил Андреевич
// 22.02.2026

#include <iostream>
#include <algorithm>

using namespace std;

int main() {
    int a, b, c, d;
    cin >> a >> b >> c >> d;

    int rects[2][2] = {{a, b}, {c, d}};

    long long best_area = 1LL << 60; 
    int best_w = 0, best_h = 0;

    
    for (int rot1 = 0; rot1 < 2; rot1++) {
        int w1 = (rot1 == 0) ? rects[0][0] : rects[0][1];
        int h1 = (rot1 == 0) ? rects[0][1] : rects[0][0];

        for (int rot2 = 0; rot2 < 2; rot2++) {
            int w2 = (rot2 == 0) ? rects[1][0] : rects[1][1];
            int h2 = (rot2 == 0) ? rects[1][1] : rects[1][0];

            int w_var1 = w1 + w2;
            int h_var1 = max(h1, h2);
            long long area_var1 = 1LL * w_var1 * h_var1;
            if (area_var1 < best_area) {
                best_area = area_var1;
                best_w = w_var1;
                best_h = h_var1;
            }

            int w_var2 = max(w1, w2);
            int h_var2 = h1 + h2;
            long long area_var2 = 1LL * w_var2 * h_var2;
            if (area_var2 < best_area) {
                best_area = area_var2;
                best_w = w_var2;
                best_h = h_var2;
            }
        }
    }

    cout << best_w << " " << best_h << endl;
    return 0;
}