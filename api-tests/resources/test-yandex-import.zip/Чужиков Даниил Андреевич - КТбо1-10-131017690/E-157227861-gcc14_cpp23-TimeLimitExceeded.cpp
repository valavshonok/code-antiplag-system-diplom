// МОП ЭВМ
// АиСП
// ДЗ №1
// Чужиков Даниил Андреевич
// 18.02.2026

#include <iostream>

using namespace std;

int main()
{
    int N, K, M;
    
    cin >> N >> K >> M;

    int total = 0;
    int waste = N;

    while (waste >= K) 
    {
        int colK = waste / K;
        int ostK = waste % K;

        int colM = colK * (K / M);
        int ostM = colK * (K % M);

        total += colM;
        waste = ostK + ostM;
    
    }

    cout << total;

    return 0;
}