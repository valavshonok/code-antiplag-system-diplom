// МОП ЭВМ
// АиСП
// ДЗ №1
// Чужиков Даниил Андреевич
// 19.02.2026

#include <iostream>
#include <algorithm>

using namespace std;

int main()
{
    int a, b, n, m;

    cin >> a >> b >> n >> m;

    int timeMinA = n + a * (n - 1);
    int timeMaxA = n + a * (n + 1);

    int timeMinB = m + b * (m - 1);
    int timeMaxB = m + b * (m + 1);


    int finalMin = max(timeMinA, timeMinB);
    int finalMax = min(timeMaxA, timeMaxB);

    if (finalMin > finalMax) {
        cout << -1 << endl;
    } else {
        cout << finalMin << " " << finalMax << endl;
    }

    return 0;
}