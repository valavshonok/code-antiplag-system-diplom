// МОП ЭВМ
// АиСП
// ДЗ №1
// Чужиков Даниил Андреевич
// 18.02.2026

#include <iostream>

using namespace std;

int main()
{
    unsigned int A, B;
    cin >> A >> B;
    cout << A+B << endl;

    return 0;
}