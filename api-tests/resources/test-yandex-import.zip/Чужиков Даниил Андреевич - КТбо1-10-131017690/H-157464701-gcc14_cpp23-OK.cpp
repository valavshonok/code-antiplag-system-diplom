// МОП ЭВМ
// АиСП
// ДЗ №1
// Чужиков Даниил Андреевич
// 23.02.2026

#include <iostream>
#include <vector>

using namespace std;

int main() {
    int n, m;
    cin >> n >> m;
    vector<vector<int>> P(n, vector<int>(m));
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            cin >> P[i][j];
        }
    }

    int q;
    cin >> q;
    while (q--) {
        int y1, y2, x1, x2;
        cin >> y1 >> y2 >> x1 >> x2;
        int ans = P[y2][x2];
        if (y1 > 0) ans -= P[y1 - 1][x2];
        if (x1 > 0) ans -= P[y2][x1 - 1];
        if (y1 > 0 && x1 > 0) ans += P[y1 - 1][x1 - 1];
        cout << ans << endl;
    }

    return 0;
}