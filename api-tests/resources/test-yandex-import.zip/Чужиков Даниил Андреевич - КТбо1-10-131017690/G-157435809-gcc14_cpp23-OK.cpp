// МОП ЭВМ
// АиСП
// ДЗ №1
// Чужиков Даниил Андреевич
// 22.02.2026

#include <iostream>
#include <vector>

using namespace std;

int main()
{
    int n;
    cin >> n;
    vector<int> a(n);
    for (int i = 0; i < n; i++)
        cin >> a[i];
    
    vector<long long> pref(n + 1, 0);
    for (int i = 0; i < n; i++)
        pref[i+1] = pref[i] + a[i];
    
    int q;
    cin >> q;
    while (q--) {
        int l, r;
        cin >> l >> r;
        cout << pref[r+1] - pref[l] << endl;
    }

    return 0;
}