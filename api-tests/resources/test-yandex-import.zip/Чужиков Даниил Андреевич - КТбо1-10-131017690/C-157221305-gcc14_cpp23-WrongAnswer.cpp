// МОП ЭВМ
// АиСП
// ДЗ №1
// Чужиков Даниил Андреевич
// 18.02.2026

#include <iostream>
#include <string>

using namespace std;

int main()
{
    int a, b, c;
    cin >> a >> b >> c;

    if (c < 0) {
        cout << "NO SOLUTION";
    } else if (a == 0 && c >= 0 && b == c*c) {
        cout << "MANY SOLUTION";
    } else if (a == 0 && c >= 0 && b != c*c) {
        cout << "NO SOLUTION";
    } else if ((c*c - b) % a != 0) {
        cout << "NO SOLUTION";
    } else {
        int x = (c * c - b) / a;
        cout << x << endl;
    }

    return 0;
}