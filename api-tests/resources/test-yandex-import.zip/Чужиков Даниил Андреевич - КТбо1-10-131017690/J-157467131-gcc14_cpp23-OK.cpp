// МОП ЭВМ
// АиСП
// ДЗ №1
// Чужиков Даниил Андреевич
// 23.02.2026

#include <iostream>
using namespace std;

int main() {
    int POLE[3][3];
    int X = 0, O = 0;
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            cin >> POLE[i][j];
            if (POLE[i][j] == 1) X++;
            else if (POLE[i][j] == 2) O++;
        }
    }

    if (!(X == O || X == O + 1)) {
        cout << "NO" << endl;
        return 0;
    }

    bool winX = false;
    for (int i = 0; i < 3; ++i) 
        if (POLE[i][0] == 1 && POLE[i][1] == 1 && POLE[i][2] == 1) winX = true; 
    for (int j = 0; j < 3; ++j) 
        if (POLE[0][j] == 1 && POLE[1][j] == 1 && POLE[2][j] == 1) winX = true;

    if (POLE[0][0] == 1 && POLE[1][1] == 1 && POLE[2][2] == 1) winX = true;
    if (POLE[0][2] == 1 && POLE[1][1] == 1 && POLE[2][0] == 1) winX = true;

    bool winO = false;
    for (int i = 0; i < 3; ++i) 
        if (POLE[i][0] == 2 && POLE[i][1] == 2 && POLE[i][2] == 2) winO = true;
    for (int j = 0; j < 3; ++j) 
        if (POLE[0][j] == 2 && POLE[1][j] == 2 && POLE[2][j] == 2) winO = true;

    if (POLE[0][0] == 2 && POLE[1][1] == 2 && POLE[2][2] == 2) 
        winO = true;
    if (POLE[0][2] == 2 && POLE[1][1] == 2 && POLE[2][0] == 2) 
        winO = true;


    if (winX && winO) 
        cout << "NO" << endl;
    else if (winX && X != O + 1) 
        cout << "NO" << endl;
    else if (winO && X != O) 
        cout << "NO" << endl;
    else 
        cout << "YES" << endl;
    

    return 0;
}
