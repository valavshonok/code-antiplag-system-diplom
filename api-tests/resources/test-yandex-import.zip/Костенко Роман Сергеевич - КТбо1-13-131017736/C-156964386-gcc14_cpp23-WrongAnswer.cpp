// ------------------------------------------------------------------
// Институт компьютерных технологий и информационной безопасности ЮФУ
// Кафедра МОП ЭВМ
// Алгоритмы и структуры данных
// Домашняя работа 1
// Задание C. Уравнение с корнем
// Исполнитель: Костенко Роман Сергеевич (КТбо1-13)
// 14.02.2026 г.
// ------------------------------------------------------------------

#include <iostream>

using namespace std;

int main()
{
    long long a, b, c, x = 0;

    cin >> a >> b >> c;

    if (c < 0)
        cout << "NO SOLUTION";
    else
    {
        if (a > 0)
        {
            while (a * (x++) + b < c * c);
            if (a * (--x) + b == c * c)
                cout << x;
            else
                cout << "NO SOLUTION";
        }
        else if (a < 0)
        {
            while (a * (x--) + b < c * c);
            if (a * (++x) + b == c * c)
                cout << x;
            else
                cout << "NO SOLUTION";
        }
        else
        {
            if (c * c == b)
                cout << "MANY SOLUTIONS";
            else
                cout << "NO SOLUTION";
        }
    }

    return 0;
}
