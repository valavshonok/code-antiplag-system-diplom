// ------------------------------------------------------------------
// Институт компьютерных технологий и информационной безопасности ЮФУ
// Кафедра МОП ЭВМ
// Алгоритмы и структуры данных
// Домашняя работа 1
// Задание H. Макс и префиксные матрицы
// Исполнитель: Костенко Роман Сергеевич (КТбо1-13)
// 20.02.2026 г.
// ------------------------------------------------------------------

#include <iostream>
#include <vector>

using namespace std;

int main()
{
    int n, m, num, q, y1k, y2k, x1k, x2k;

    cin >> n >> m;

    vector<vector<int>> arr(n + 1, vector<int>(m + 1));
    vector<vector<int>> arr0(2, vector<int>(m + 1));

    for (int i = 1; i < n + 1; ++i)
    {
        arr[i % 2][0] = 0;
        for (int j = 1; j < m + 1; ++j)
        {
            cin >> num;
            arr0[i % 2][j] = num;
            if (i % 2) arr[i][j] = (arr0[i % 2 - 1][j - 1] - arr0[i % 2 - 1][j] - arr0[i % 2][j - 1] + num);
            else arr[i][j] = (arr0[i % 2 + 1][j - 1] - arr0[i % 2 + 1][j] - arr0[i % 2][j - 1] + num);
        }
    }

    cin >> q;

    for (int k = 0; k < q; ++k)
    {
        cin >> y1k >> y2k >> x1k >> x2k;

        int cnt = 0;

        for (int i = y1k; i <= y2k; ++i)
            for (int j = x1k; j <= x2k; ++j)
                cnt += arr[i + 1][j + 1];

        cout << cnt << '\n';
    }

    return 0;
}
