// ------------------------------------------------------------------
// Институт компьютерных технологий и информационной безопасности ЮФУ
// Кафедра МОП ЭВМ
// Алгоритмы и структуры данных
// Домашняя работа 1
// Задание F. Метро
// Исполнитель: Костенко Роман Сергеевич (КТбо1-13)
// 22.02.2026 г.
// ------------------------------------------------------------------

//{
#include <iostream>
#include <set>
#include <map>
#include <string>
#include <queue>
#include <deque>
#include <stack>
#include <vector>
#include <cmath>
#include <iomanip>
#include <algorithm>
#include <cstdlib>
#include <bitset>
#include <numeric>
#include <memory.h>
#include <utility>
using namespace std;
typedef unsigned long long ull;
typedef long long ll;
typedef double db;
typedef float ft;
const int MOD = 1e9 + 7;
const db EPS = 1e-9;
const db PI = 3.141592653589793238462643383279502884;
#define endl '\n'
#define space << ' ' <<
#define cendl cout << '\n';
#define v(type) vector<type>
#define w(type) vector<vector<type>>
#define p(type1, type2) pair<type1, type2>
#define d(type) deque<type>
#define s(type) set<type>
#define ms(type) multiset<type>
#define m(type1, type2) map<type_1, type_2>
#define vp(type1, type2) vector<pair<type_1, type_2>>
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
//}

int cntWin(int N, w(int) arr, int xyc)
{
    int cnt = 0;

    for (int i = 0; i < N; ++i)
    {
        if (arr[i][0] == xyc && arr[i][1] == xyc && arr[i][2] == xyc)
            cnt++;
        if (arr[0][i] == xyc && arr[1][i] == xyc && arr[2][i] == xyc)
            cnt++;
    }

    if (arr[0][0] == xyc && arr[1][1] == xyc && arr[2][2] == xyc)
        cnt++;

    if (arr[0][2] == xyc && arr[1][1] == xyc && arr[2][0] == xyc)
        cnt++;

    return cnt;
}

int main()
{
    cin.tie(0)->sync_with_stdio(0);

    int n = 3, cntX = 0, cntO = 0, cntWinX = 0, cntWinO = 0, X = 1, O = 2;

    w(int) arr(n, v(int)(n));

    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < n; ++j)
        {
            cin >> arr[i][j];
            if (arr[i][j] == X) cntX++;
            else if (arr[i][j] == O) cntO++;
        }
    }

    if (cntX != cntO + (cntX > cntO))
        cout << "NO" << '\n';

    else
    {
        cntWinX = cntWin(n, arr, X);
        cntWinO = cntWin(n, arr, O);
        if ((cntWinX && !cntWinO && cntX - cntO == 1) || (!cntWinX && cntWinO && cntX == cntO) || (!cntWinX && !cntWinO))
            cout << "YES" << '\n';
        else
            cout << "NO" << '\n';
    }

    return 0;
}
