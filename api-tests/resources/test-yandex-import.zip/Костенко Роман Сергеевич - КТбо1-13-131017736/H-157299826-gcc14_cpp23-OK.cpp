// ------------------------------------------------------------------
// Институт компьютерных технологий и информационной безопасности ЮФУ
// Кафедра МОП ЭВМ
// Алгоритмы и структуры данных
// Домашняя работа 1
// Задание H. Макс и префиксные матрицы
// Исполнитель: Костенко Роман Сергеевич (КТбо1-13)
// 20.02.2026 г.
// ------------------------------------------------------------------

#include <iostream>
#include <vector>

using namespace std;

int main()
{
    int n, m, q, y1k, y2k, x1k, x2k;

    cin >> n >> m;

    vector<vector<int>> arr(n + 1, vector<int>(m + 1));
    vector<vector<int>> arr0(2, vector<int>(m + 1));

    for (int i = 1; i < n + 1; ++i)
    {
        for (int j = 1; j < m + 1; ++j)
        {
            cin >> arr0[i % 2][j];
            arr[i][j] = arr0[1 - i % 2][j - 1] + arr0[i % 2][j] - arr0[1 - i % 2][j] - arr0[i % 2][j - 1] +
                        arr[i - 1][j] + arr[i][j - 1] - arr[i - 1][j - 1];
        }
    }

    cin >> q;

    for (int k = 0; k < q; ++k)
    {
        cin >> y1k >> y2k >> x1k >> x2k;

        cout << (arr[y2k + 1][x2k + 1] + arr[y1k][x1k] - arr[y1k][x2k + 1] - arr[y2k + 1][x1k]) << '\n';
    }

    return 0;
}