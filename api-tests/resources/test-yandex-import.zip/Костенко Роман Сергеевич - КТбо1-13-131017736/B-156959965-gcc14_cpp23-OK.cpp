// ------------------------------------------------------------------
// Институт компьютерных технологий и информационной безопасности ЮФУ
// Кафедра МОП ЭВМ
// Алгоритмы и структуры данных
// Домашняя работа 1
// Задание B. Кондиционер
// Исполнитель: Костенко Роман Сергеевич (КТбо1-13)
// 14.02.2026 г.
// ------------------------------------------------------------------

#include <iostream>

using namespace std;

int main()
{
    int t_room, t_cond;
    string operatingMode;

    cin >> t_room >> t_cond >> operatingMode;

    if (operatingMode == "fan")
        cout << t_room;
    else if (operatingMode == "auto")
        cout << t_cond;
    else if (operatingMode == "freeze")
    {
        if (t_room <= t_cond)
            cout << t_room;
        else
            cout << t_cond;
    }
    else
    {
        if (t_room >= t_cond)
            cout << t_room;
        else
            cout << t_cond;
    }
    return 0;
}
