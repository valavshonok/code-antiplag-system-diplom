// ------------------------------------------------------------------
// Институт компьютерных технологий и информационной безопасности ЮФУ
// Кафедра МОП ЭВМ
// Алгоритмы и структуры данных
// Домашняя работа 1
// Задание F. Метро
// Исполнитель: Костенко Роман Сергеевич (КТбо1-13)
// 22.02.2026 г.
// ------------------------------------------------------------------

//{
#include <iostream>
#include <set>
#include <map>
#include <string>
#include <queue>
#include <deque>
#include <stack>
#include <vector>
#include <cmath>
#include <iomanip>
#include <algorithm>
#include <cstdlib>
#include <bitset>
#include <numeric>
#include <memory.h>
#include <utility>
using namespace std;
typedef unsigned long long ull;
typedef long long ll;
typedef double db;
typedef float ft;
const int MOD = 1e9 + 7;
const db EPS = 1e-9;
const db PI = 3.141592653589793238462643383279502884;
#define endl '\n'
#define space << ' ' <<
#define cendl cout << '\n';
#define v(type) vector<type>
#define w(type) vector<vector<type>>
#define p(type1, type2) pair<type1, type2>
#define d(type) deque<type>
#define s(type) set<type>
#define ms(type) multiset<type>
#define m(type1, type2) map<type_1, type_2>
#define vp(type1, type2) vector<pair<type_1, type_2>>
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
//}


int main()
{
    cin.tie(0)->sync_with_stdio(0);

    int a, b, n, m;

    cin >> a >> b >> n >> m;

    int minA = n * (a + 1) - a;
    int minB = m * (b + 1) - b;
    int minTime = max(minA, minB);

    int maxA = n * (a + 1) + a;
    int maxB = m * (b + 1) + b;
    int maxTime = min(maxA, maxB);

    if (maxTime >= minTime)
        cout << minTime space maxTime;
    else
        cout << -1;


    return 0;
}
